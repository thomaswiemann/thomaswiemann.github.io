# Toy simulations for illustrating computation on Acropolis.
#
# Author: Thomas Wiemann
# Date: November 9, 2021
#
# This script simulates from a simple linear DGP and calculates the OLS 
#     coefficient. The result is stored in a .csv file in the folder 
#     ``temp/toy_example_jl/``.
#
# Results can be aggregated by running the ``combine_sim.jl`` script where 
#    [SIM_NAME] is set to ``toy_example_jl``.

# Preliminaries ================================================================

# Load additional dependencies
using DataFrames, CSV
using Distributions

# Simulation hyperparameters
nobs = 100
nX = 3

# Simulate from a linear DGP ===================================================

# This section simulates from the linear regression model. 
X = randn((nobs, nX))
β = randn(nX)
ϵ = randn(nobs)
y = X * β + ϵ

# Estimation ===================================================================

# Calculates the ols coefficient
β_ols = inv(X' * X) * (X' * y)

# Store results ================================================================

# Compile the results to a data frame. Only store the first coefficent (which 
#     may be the coefficient of interest in an empirical example).
res = DataFrame(coef = β_ols[1], 
    absolute_bias = abs(β_ols[1] - β[1]),
    coef_0 = β[1])

# Construct directory and file names
dir_name = pwd() * "/temp/toy_example_jl"
file_name = "/res_" * ENV["PBS_ARRAYID"] * ".csv"

# Create the directory if necessary
if !isdir(dir_name)
    mkdir(dir_name)
end

# Write the data frame to a .csv file
CSV.write(dir_name * file_name, res)