# Aggeragate simulations results.
# 
# Author: Thomas Wiemann
# Data: November 9, 2021
#
# This script aggergates the simulation results stored in ``temp/[SIM_NAME]``. 
#    Several statistics are calculated and stored in a new .csv file 
#    ``Results/[SIM_NAME]/[FILE_NAME].csv``.
#
# To execute the script, run the following command in the terminal:
#     julia "julia_scripts/combine_sim.jl" [SIM_NAME] [FILE_NAME] [DELETE_TEMP]
#
# [SIM_NAME] should be the folder where the temporary .csv files are stored. 
#    [FILE_NAME] is the name of the .csv file where the aggregated results will
#    stored. [DELETE_TEMP] should be ``true`` if the temporary .csv and log 
#    files should be deleted.

# Preliminaries ================================================================

# Load arguments
if length(ARGS) < 2
    println("Please pass SIM_NAME and FILE_NAME as arguments.")
    exit(86)
else
    SIM_NAME = ARGS[1]
    FILE_NAME = ARGS[2]
end
length(ARGS) == 3 ? DELETE_TEMP = (ARGS[3] == "true") : DELETE_TEMP = false

# Load dependencies
using DataFrames, CSV
using Statistics

# Load the simulation results ==================================================

# Construct the directory name and get the file names
dir_name = pwd() * "/temp/" * SIM_NAME
file_names = readdir(dir_name)
n_files = length(file_names)

# Get dimensions from first file 
file_name = dir_name * "/" * file_names[1]
res_1 = CSV.read(file_name, DataFrame)

# Collect simulation results from each file
res_array = zeros((nrow(res_1), ncol(res_1), n_files))
for j in 1:n_files
    # Load file
    file_name = dir_name * "/" * file_names[j]
    res_j = CSV.read(file_name, DataFrame)
    # Store the results
    res_array[:, :, j] .= res_j
end

# Aggregation ==================================================================

# Calculate the mean, standard deviation, and median for each passed variable
#    is calculated. 
res_mat = cat(mapslices(mean, res_array, dims = 3)[1, :, 1],
    mapslices(std, res_array, dims = 3)[1, :, 1],
    mapslices(median, res_array, dims = 3)[1, :, 1], dims = 2)

# Results are stored in a data frame.
res_df = DataFrame(res_mat, :auto)
rename!(res_df, [:mean, :std, :median])
insertcols!(res_df, 1, :Variable => names(res_1))

# Add the number of simulations
push!(res_df, ["Number of simulations" n_files 0 0])

# Store aggregated simulation results ==========================================

# Construct directory and file names
dir_name = pwd() * "/Results/" * SIM_NAME
file_name = "/" * FILE_NAME * ".csv"

# Create the directory if necessary
if !isdir(dir_name)
    mkdir(dir_name)
end

# Write the data frame to a .csv file
CSV.write(dir_name * file_name, res_df)

# Cleanup (optional) ===========================================================

# Delete all temporary .csv files with the simulation results.
if DELETE_TEMP
    # Asks for user input to confirm whether all results should be deleted.
    println("Do you want to delete all temporary .csv and log files? [y/n]")
    confirmation = readline() 
    if confirmation == "y"
        # Delete the temporary .csv files
        rm(pwd() * "/temp/" * SIM_NAME, recursive = true)
        # Delete all log files but recreate the ``/temp/log`` directory
        rm(pwd() * "/temp/log", recursive = true)
        mkdir(pwd() * "/temp/log")
    else
        println("No files have been deleted.")
    end
end