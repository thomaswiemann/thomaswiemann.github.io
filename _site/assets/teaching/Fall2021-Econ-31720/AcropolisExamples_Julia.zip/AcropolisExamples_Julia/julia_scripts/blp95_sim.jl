# Simulations based on Berry, Levinsohn, Pakes (1995).
#
# Author: Thomas Wiemann
# Date: November 9, 2021
#
# This script computes the two-stage least squares (Theil, 1953) coefficient 
#    of price on the market share of a firm using simulated data based on Berry, 
#    Levinsohn, Pakes (1995) (BLP1995, hereafter). Variables are constructed as 
#    in Chernozhukov, Hansen, and Spindler (2015) (CHS2015, hereafter). The data 
#    was retrieved from 
#    https://www.aeaweb.org/articles?id=10.1257/aer.p20151022/. 
#
# The computed coefficient, its associated heteroskedasticity robust standard 
#     error, and whether it covers the true coefficient are stored in a .csv 
#     file in the folder ``temp/blp95_sim/`` and numbered using the array-id of 
#     the corresponding cluster job. 
#
# Results can be aggregated by running the ``combine_sim.jl`` script where 
#    [SIM_NAME] is set to ``blp95_sim``.

# Preliminaries ================================================================

# Load the MyMethods package. Can be installed via GitHub using Pkg. I.e., run: 
# using Pkg;
# Pkg.add(url="https://github.com/thomaswiemann/MyMethods.jl")
using MyMethods

# Load additional dependencies
using DataFrames, CSV, MAT
using Distributions

# Simulation hyperparameters
κ_1 = 5.27
κ_2 = 1.05
rho = 0.3
bootstrap_XZ = true

# Data =========================================================================

# Load BLP data
BLP_dat = matread("Data/BLP_data.mat")

# Select key variables of interest as in CHS2015
id = BLP_dat["id"]
firmid = BLP_dat["firmid"]
cdid = BLP_dat["cdid"]
y = @. log(BLP_dat["share"]) - log(BLP_dat["outshr"])
D = BLP_dat["price"]
X = cat(BLP_dat["hpwt"], BLP_dat["air"], 
    BLP_dat["mpd"], BLP_dat["space"], dims = 2)
nobs = length(y)

# Construct the BLP1995 instruments. Instruments are sums of product
#     characteristics (excluding price and other potentially endogenous
#     variables) of other products offered by the firm as well as over
#     competing firms. The exact instrument specification here follows the
#     approach of CHS2015.
sum_other = zeros((nobs, 4))
sum_rival = zeros((nobs, 4))
for i in 1:nobs
    other_id = @. (firmid == firmid[i]) & (cdid == cdid[i]) & (id != id[i])
    other_id = findall(other_id[:, 1])
    rival_ind = @. (firmid != firmid[i]) & (cdid == cdid[i])
    rival_ind = findall(rival_ind[:, 1])

    sum_other[i, :] = mapslices(sum, X[other_id, :], dims = 1)
    sum_rival[i, :] = mapslices(sum, X[rival_ind, :], dims = 1)
end
Z = cat(sum_other, sum_rival, dims = 2)
X = cat(ones(nobs), X, dims = 2)

# Simulate from the BLP-DGP ====================================================

# This section simulates from the linear IV model fitted to BLP1995. First, the 
#     first and second stage estimates are calculated using manual TSLS. 
fit_fs = myLS(D, cat(X, Z, dims = 2)) # First stage
fit_ss = myLS(y, cat(predict(fit_fs), X, dims = 2)) # Manual second stage

# An estimate of the heteroskedasticity is constructed using a simple 
#     regression of the squared TSLS-residuals on X.
u = y - predict(fit_ss, cat(D, X, dims = 2))
fit_hc = myLS(u.^2, X)

# Bootstrap X and Z (optional)
if bootstrap_XZ
    indx_b = rand(1:nobs, nobs)
    X_b = X[indx_b, :]
    Z_b = Z[indx_b, :]
else 
    # This is of course not memory-efficient, but data is very small here so...
    X_b = X
    Z_b = Z
end

# Simulate the first stage
nu = randn(nobs)
D_s = predict(fit_fs, cat(X_b, Z_b, dims = 2)) + κ_1 * nu

# Simulate the second stage
eps = randn(nobs)
ω = sqrt.(predict(fit_hc, X_b))
y_s = predict(fit_ss, cat(D_s, X_b, dims = 2)) + ω .* (κ_2 * eps + rho * nu)

# Estimation ===================================================================

# This estimates the TSLS coefficient on the simlated data, calculates the 
#    associated standard error, and assesses coverage.
fit_tsls = myTSLS(y_s, D_s, Z_b, X_b)
coef = fit_tsls.β[1]
se = inference(fit_tsls, heteroskedastic = true, print_df = false).se[1]
covered = (fit_ss.β[1] >= fit_tsls.β[1] - 1.96 * se) | 
    (fit_ss.β[1] <= fit_tsls.β[1] + 1.96 * se) 

# Store results ================================================================

# Compile the results to a data frame. Also include moments of the data.
res = DataFrame(coef = coef, 
    se = se, 
    covered_95 = covered * 1,
    absolute_bias = abs(coef - fit_ss.β[1]),
    tsls_coef = fit_ss.β[1],
    var_D = var(D),
    var_Ds = var(D_s),
    var_y = var(y),
    var_ys = var(y_s),
    ols_coef = myLS(y, cat(D, X, dims = 2)).β[1],
    ols_coef_s = myLS(y_s, cat(D_s, X_b, dims = 2)).β[1])

# Construct directory and file names
dir_name = pwd() * "/temp/blp95_sim"
file_name = "/res_" * ENV["PBS_ARRAYID"] * ".csv"

# Create the directory if necessary
if !isdir(dir_name)
    mkdir(dir_name)
end

# Write the data frame to a .csv file
CSV.write(dir_name * file_name, res)