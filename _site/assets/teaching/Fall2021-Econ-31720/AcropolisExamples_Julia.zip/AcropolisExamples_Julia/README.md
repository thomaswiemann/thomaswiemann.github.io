# AcropolisExamples
A collection of simple examples for submitting jobs on the SSCS Acropolis cluster.

## Submission of Monte Carlo Simulation Instances

To run a simple toy example, run the following code in the Acropolis terminal. Make sure that your working directory is set to the project folder.

```bash
qsub qsub/toy_example_jl.qsub
```

You can submit the simulations based on BLP1995 in a similar fashion by calling:
```bash
qsub qsub/blp95_sim.qsub
```

To change the number of allocated resources or the number of simulations, edit the ``.qsub`` files directly.


## Aggregation of the Simulation Results
The simulation results can be aggregated by running the following command in 
the console:
```bash
julia "julia_scripts/combine_sim.jl" [SIM_NAME] [FILE_NAME] [DELETE_TEMP]
```

For example, to aggergate results from the BLP1995-based simulation and delete the 
temporary .csv files, simply run the following:
```bash
julia "julia_scripts/combine_sim.jl" blp95_sim blp95_res true
```
The aggregated resuts are stored then stored in ``Results/blp95_res.csv``, as
dictated by the second argument.

## Managing Jobs

To check the status of your jobs, simply run ``qstat`` in the Acropolis terminal.

To cancel a job on acropolis, run ``qstat [JOB_ID]`` where ``[JOB_ID]`` should be 
replaced with the id of the job (which you can find by running ``qstat``).