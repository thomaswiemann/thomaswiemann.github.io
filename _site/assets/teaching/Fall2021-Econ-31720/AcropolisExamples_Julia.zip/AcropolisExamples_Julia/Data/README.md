Data from Berry, Levinsohn, Pakes (1995) as retrived from the reproduction
excercise in Chernozhukov, Hansen, and Spindler (2015). 

https://www.aeaweb.org/articles?id=10.1257/aer.p20151022/